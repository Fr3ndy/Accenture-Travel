# server-fake

To launch server type the following command:

```
npm start
```

## Endpoints:

```
localhost:3004/hotels

localhost:3004/restaurants

localhost:3004/flights

localhost:3004/places

localhost:3004/memory
```

