const faker                   = require('faker');
const _                       = require('lodash');

var carte = ["rosso-A", "viola-A", "bianco-A", "giallo-azzurro-A", "giallo-A", "rainbow-A", "rosso-B", "viola-B", "bianco-B", "giallo-azzurro-B", "giallo-B", "rainbow-B"];

const memoryEndpoint = () => {
	console.log('Inizio memoryEndpoint');
    let listaCarteJson = [];

    for (let i in carte) {
        listaCarteJson.push({
            name: carte[i]
        });
    }

	console.log('numero carte: ' + listaCarteJson.length);
    return listaCarteJson;
}




module.exports = memoryEndpoint();